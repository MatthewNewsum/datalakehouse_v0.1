import boto3
import pandas as pd
from io import BytesIO

def lambda_handler(event, context):
    source_bucket_name = "demo-lakehouse-raw-zone"
    source_folder_name = "cta-data"
    source_file_name = "ctarawdata.json"

    destination_bucket_name = "demo-lakehouse-processed-zone"
    destination_folder_name = "cta-data"
    destination_file_name = "ctarawdata_cleaned.parquet"

    try:
        s3 = boto3.client('s3')

        response = s3.get_object(Bucket=source_bucket_name, Key=f"{source_folder_name}/{source_file_name}")
        raw_data = response['Body'].read().decode('utf-8')

        data = pd.read_json(BytesIO(raw_data.encode('utf-8')))

        day_type_mapping = {
            'W': 'Weekday',
            'A': 'Saturday',
            'U': 'Sunday/Holiday'
        }
        data['day_type'] = data['day_type'].map(day_type_mapping).fillna(data['day_type'])

        parquet_buffer = BytesIO()
        data.to_parquet(parquet_buffer, index=False)

        s3.put_object(
            Bucket=destination_bucket_name,
            Key=f"{destination_folder_name}/{destination_file_name}",
            Body=parquet_buffer.getvalue()
        )

        return {
            "statusCode": 200,
            "body": '{"message": "Data cleaned and saved as Parquet successfully."}'
        }

    except boto3.exceptions.Boto3Error as e:
        print(f"Error with S3 operation: {e}")
        return {
            "statusCode": 500,
            "body": '{"message": "Error processing S3 operation."}'
        }

    except ValueError as e:
        print(f"Error processing data: {e}")
        return {
            "statusCode": 500,
            "body": '{"message": "Error processing data."}'
        }