import boto3
import json
import os
 
def lambda_handler(event, context):
    source_bucket_name = "demo-lakehouse-raw-zone"
    source_folder_name = "cta-data"
    source_file_name = "ctarawdata.json"
 
    destination_bucket_name = "demo-lakehouse-processed-zone"
    destination_folder_name = "cta-data"
    destination_file_name = "ctarawdata_cleaned.json"
 
    try:
        s3 = boto3.client('s3')
 
        response = s3.get_object(Bucket=source_bucket_name, Key=f"{source_folder_name}/{source_file_name}")
        raw_data = response['Body'].read().decode('utf-8')
        data = json.loads(raw_data)
 
        for record in data:
            if 'day_type' in record:
                if record['day_type'] == 'W':
                    record['day_type'] = 'Weekday'
                elif record['day_type'] == 'A':
                    record['day_type'] = 'Saturday'
                elif record['day_type'] == 'U':
                    record['day_type'] = 'Sunday/Holiday'
 
        cleaned_data = json.dumps(data, indent=2)
 
        s3.put_object(Bucket=destination_bucket_name, Key=f"{destination_folder_name}/{destination_file_name}", Body=cleaned_data)
 
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Data cleaned and duplicated successfully."})
        }
 
    except boto3.exceptions.Boto3Error as e:
        print(f"Error with S3 operation: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Error processing S3 operation."})
        }
 
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Error decoding JSON."})
        }